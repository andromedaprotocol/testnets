# Protobufs

This is the public protocol buffers API for [Wasmd](https://github.com/CosmWasm/wasmd).