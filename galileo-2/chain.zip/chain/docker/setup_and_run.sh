#!/bin/sh

./setup_andromedad.sh "$@"
./run_andromedad.sh