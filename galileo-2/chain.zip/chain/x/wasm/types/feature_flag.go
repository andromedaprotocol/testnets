package types

// Tests should not fail on gas consumption
const EnableGasVerification = true
